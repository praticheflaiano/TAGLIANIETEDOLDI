import React from 'react';
import { ChevronRight, ShieldCheck, Activity } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div id="home" className="relative min-h-screen flex items-end lg:items-center bg-slate-950 overflow-hidden pt-28 lg:pt-20">
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-blue-900/40 via-slate-950 to-slate-950"></div>
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03]"></div>
      
      {/* Animated Glows */}
      <div className="absolute top-20 right-0 w-[600px] h-[600px] bg-blue-600/20 blur-[120px] rounded-full mix-blend-screen animate-pulse duration-700"></div>
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-teal-600/10 blur-[100px] rounded-full mix-blend-screen"></div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full h-full flex flex-col lg:flex-row">
        
        {/* Text Content (Left Side) */}
        <div className="w-full lg:w-1/2 flex flex-col justify-center pb-12 lg:pb-0 z-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-900/30 border border-blue-500/30 text-blue-300 text-xs font-bold uppercase tracking-widest w-fit mb-6 backdrop-blur-sm">
            <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse"></span>
            Medical Devices & Consultancy
          </div>
          
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-extrabold text-white mb-6 leading-[1.1] tracking-tight">
            Eccellenza in <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-blue-200 to-teal-200">
              Ortopedia
            </span>
          </h1>
          
          <p className="text-lg md:text-xl text-slate-400 mb-10 leading-relaxed max-w-xl border-l-4 border-blue-600 pl-6">
            Partner strategici per la sanità lombarda da oltre 30 anni.
            Tecnologia, competenza e supporto in sala operatoria.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <a 
              href="#servizi" 
              className="group inline-flex items-center justify-center px-8 py-4 text-base font-bold rounded-full text-white bg-blue-600 hover:bg-blue-500 transition-all shadow-[0_0_20px_rgba(37,99,235,0.4)] hover:shadow-[0_0_30px_rgba(37,99,235,0.6)] transform hover:-translate-y-1"
            >
              I Nostri Servizi
            </a>
            <a 
              href="#contatti" 
              className="inline-flex items-center justify-center px-8 py-4 text-base font-bold rounded-full text-slate-300 bg-white/5 border border-white/10 hover:bg-white/10 hover:text-white backdrop-blur-sm transition-all"
            >
              Contattaci <ChevronRight className="ml-2 h-4 w-4" />
            </a>
          </div>

          <div className="mt-12 flex items-center gap-8 text-slate-500">
            <div className="flex items-center gap-2">
              <ShieldCheck className="text-blue-500" />
              <span className="text-sm font-medium">Certificati ISO</span>
            </div>
            <div className="flex items-center gap-2">
              <Activity className="text-teal-500" />
              <span className="text-sm font-medium">Assistenza H24</span>
            </div>
          </div>
        </div>

        {/* Image Content (Right Side) */}
        <div className="w-full lg:w-1/2 flex items-end justify-center lg:justify-end relative h-[50vh] lg:h-auto min-h-[500px]">
           {/* Light glow behind the people */}
           <div className="absolute bottom-0 right-10 w-[80%] h-[80%] bg-gradient-to-t from-blue-600/20 to-transparent blur-3xl rounded-full"></div>
           
           <div className="relative z-10 w-auto h-full max-h-[750px] flex items-end">
              {/* 
                 NOTE: Adjust 'object-contain' and heights to best fit your specific cutout PNG.
                 The gradient overlay at the bottom ensures a smooth fade into the footer/section break if the photo cuts off.
              */}
              <img 
                src="https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=1000&auto=format&fit=crop" 
                alt="Nicola Tagliani & Alessandro Tedoldi" 
                className="h-full w-full object-contain object-bottom drop-shadow-2xl filter brightness-105 contrast-105"
                style={{ maskImage: 'linear-gradient(to bottom, black 80%, transparent 100%)' }}
              />
           </div>

           {/* Floating Info Card */}
           <div className="absolute bottom-10 -left-4 lg:left-0 bg-white/10 backdrop-blur-md border border-white/20 p-5 rounded-2xl shadow-2xl z-20 max-w-[260px] hidden sm:block animate-fade-in-up">
              <p className="text-blue-400 font-bold text-xs uppercase tracking-wider mb-1">Founders</p>
              <p className="text-white font-bold text-lg leading-tight">Nicola Tagliani <br/>& Alessandro Tedoldi</p>
              <div className="mt-3 h-1 w-12 bg-blue-500 rounded-full"></div>
           </div>
        </div>

      </div>
    </div>
  );
};

export default Hero;