import React from 'react';
import { PartnerCategory, BrandItem } from '../types';

const categories: PartnerCategory[] = [
  { category: "Ortopedia", description: "Protesi e impianti articolari" },
  { category: "Trauma", description: "Fissazione e ricostruzione" },
  { category: "Rigenerativa", description: "Terapie biologiche avanzate" },
  { category: "Custom 3D", description: "Impianti personalizzati" },
];

const brands: BrandItem[] = [
  { name: "Lima Ortho", description: "Dispositivi Ortopedici" },
  { name: "MedTech Pro", description: "Tecnologie Medicali" },
  { name: "OrthoPro", description: "Impianti Ortopedici" },
  { name: "BioMedics", description: "Strumentazione Chirurgica" },
  { name: "Trauma Solutions", description: "Sistemi Traumatologici" },
  { name: "Regen Health", description: "Medicina Rigenerativa" },
  { name: "3D Ortho Print", description: "Stampa 3D Medicale" },
  { name: "Articulo Systems", description: "Protesi Articolari" },
  { name: "Spine Dynamics", description: "Chirurgia Spinale" },
];

const Partners: React.FC = () => {
  return (
    <section id="partner" className="py-24 bg-slate-900 text-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-900/20 rounded-full blur-[100px] pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-teal-900/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Partnership d'Eccellenza</h2>
            <p className="text-xl text-slate-400 font-light">
              Collaboriamo solo con i leader mondiali dell'innovazione medicale per garantire il massimo standard di cura.
            </p>
          </div>
          
          <div className="hidden md:flex gap-2">
            {categories.map((item, idx) => (
              <div key={idx} className="px-4 py-2 rounded-full border border-slate-700 bg-slate-800/50 text-xs font-medium text-slate-300 backdrop-blur-sm">
                {item.category}
              </div>
            ))}
          </div>
        </div>

        {/* Brands Grid - Modern Badges */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-20">
          {brands.map((brand, idx) => (
            <div 
              key={idx} 
              className="group relative flex items-center justify-between p-6 bg-slate-800/50 rounded-xl border border-slate-700/50 hover:bg-slate-800 hover:border-blue-500/50 transition-all duration-300 cursor-default"
            >
              <div>
                <span className="font-bold text-lg text-white block group-hover:text-blue-400 transition-colors">{brand.name}</span>
                <span className="text-xs text-slate-500 uppercase tracking-wider">{brand.description}</span>
              </div>
              <div className="h-2 w-2 rounded-full bg-slate-600 group-hover:bg-blue-400 group-hover:shadow-[0_0_10px_rgba(96,165,250,0.8)] transition-all"></div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="relative rounded-3xl overflow-hidden p-8 sm:p-16 text-center border border-slate-700 bg-gradient-to-b from-slate-800 to-slate-900 shadow-2xl">
          <div className="relative z-10">
            <h3 className="text-3xl font-bold mb-4">Vuoi collaborare con noi?</h3>
            <p className="text-slate-400 mb-8 max-w-xl mx-auto">Siamo sempre alla ricerca di nuove tecnologie per migliorare la vita dei pazienti.</p>
            <a href="#contatti" className="inline-block bg-white text-slate-900 font-bold py-4 px-10 rounded-full hover:bg-blue-50 transition-all transform hover:scale-105 shadow-[0_0_20px_rgba(255,255,255,0.2)]">
              Parla con noi
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};

export default Partners;