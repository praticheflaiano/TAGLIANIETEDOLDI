import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, ArrowRight } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Chi Siamo', href: '#chi-siamo' },
    { name: 'Servizi', href: '#servizi' },
    { name: 'Partner', href: '#partner' },
  ];

  return (
    <nav 
      className={`fixed w-full z-50 transition-all duration-500 border-b ${
        scrolled 
          ? 'bg-slate-900/90 backdrop-blur-md border-slate-800 py-3 shadow-xl' 
          : 'bg-transparent border-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center group cursor-pointer">
            <a href="#home" className="flex flex-col">
              <span className="font-bold text-2xl tracking-tighter uppercase text-white group-hover:text-blue-400 transition-colors">
                Tagliani <span className="text-blue-500">&</span> Tedoldi
              </span>
              <span className="text-[10px] tracking-[0.2em] text-slate-400 uppercase hidden sm:block">Medical Devices</span>
            </a>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-1">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="px-4 py-2 text-sm font-medium text-slate-300 hover:text-white hover:bg-white/5 rounded-full transition-all"
              >
                {link.name}
              </a>
            ))}
            <div className="pl-4 ml-4 border-l border-slate-700">
              <a
                href="#contatti"
                className="flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-bold bg-blue-600 text-white hover:bg-blue-500 transition-all shadow-[0_0_20px_rgba(37,99,235,0.3)] hover:shadow-[0_0_30px_rgba(37,99,235,0.5)] transform hover:-translate-y-0.5"
              >
                <Phone size={16} />
                <span>Contattaci</span>
              </a>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown */}
      <div className={`md:hidden absolute top-full left-0 w-full bg-slate-900 border-b border-slate-800 shadow-2xl transition-all duration-300 ease-in-out origin-top ${isOpen ? 'opacity-100 scale-y-100' : 'opacity-0 scale-y-0 h-0 overflow-hidden'}`}>
        <div className="px-4 py-6 space-y-3">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={() => setIsOpen(false)}
              className="block px-4 py-3 text-base font-medium text-slate-300 hover:text-white hover:bg-white/5 rounded-lg border border-transparent hover:border-slate-700 transition-all"
            >
              {link.name}
            </a>
          ))}
          <a
            href="#contatti"
            onClick={() => setIsOpen(false)}
            className="mt-4 flex w-full items-center justify-center gap-2 px-4 py-4 rounded-lg text-base font-bold bg-blue-600 text-white active:bg-blue-700"
          >
            Contattaci <ArrowRight size={18} />
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;