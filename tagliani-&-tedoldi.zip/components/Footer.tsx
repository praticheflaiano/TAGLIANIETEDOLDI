import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          
          {/* Brand */}
          <div className="col-span-1 md:col-span-2 lg:col-span-1">
            <h3 className="text-white text-xl font-bold mb-4 uppercase tracking-wider">
              Tagliani <span className="text-blue-500">&</span> Tedoldi
            </h3>
            <p className="text-sm leading-relaxed mb-4">
              Specialisti in dispositivi medici per ortopedia e traumatologia con oltre 30 anni di esperienza.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-white font-bold mb-4">Link Rapidi</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#home" className="hover:text-white transition-colors">Home</a></li>
              <li><a href="#chi-siamo" className="hover:text-white transition-colors">Chi Siamo</a></li>
              <li><a href="#servizi" className="hover:text-white transition-colors">Servizi</a></li>
              <li><a href="#partner" className="hover:text-white transition-colors">Partner</a></li>
            </ul>
          </div>

          {/* Services Links */}
           <div>
            <h4 className="text-white font-bold mb-4">Servizi</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#servizi" className="hover:text-white transition-colors">Dispositivi Medici</a></li>
              <li><a href="#servizi" className="hover:text-white transition-colors">Articoli Ortopedici</a></li>
              <li><a href="#servizi" className="hover:text-white transition-colors">Consulenza Tecnica</a></li>
              <li><a href="#servizi" className="hover:text-white transition-colors">Formazione</a></li>
            </ul>
          </div>

          {/* Contacts Mini */}
          <div>
            <h4 className="text-white font-bold mb-4">Contatti</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start">
                <MapPin size={16} className="mr-2 mt-0.5 text-blue-500" />
                <span>Via Creta 26, 25124 Brescia</span>
              </li>
              <li className="flex items-center">
                <Phone size={16} className="mr-2 text-blue-500" />
                <a href="tel:+393482618794" className="hover:text-white">+39 348 2618794</a>
              </li>
              <li className="flex items-center">
                <Mail size={16} className="mr-2 text-blue-500" />
                <a href="mailto:tagliani.tedoldi@gmail.com" className="hover:text-white">tagliani.tedoldi@gmail.com</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 mt-8 text-center md:text-left flex flex-col md:flex-row justify-between items-center text-xs">
          <p>&copy; {currentYear} Tagliani & Tedoldi S.r.l. - P.IVA 04212480984 - Tutti i diritti riservati.</p>
          <div className="mt-4 md:mt-0 space-x-4">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;