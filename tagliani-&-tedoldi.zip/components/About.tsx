import React from 'react';
import { CheckCircle2, Award, Users, Clock } from 'lucide-react';
import { StatItem } from '../types';

const stats: StatItem[] = [
  { value: '30+', label: 'Anni di Esperienza' },
  { value: '100%', label: 'Affidabilità' },
  { value: '24/7', label: 'Reperibilità' },
];

const About: React.FC = () => {
  return (
    <section id="chi-siamo" className="py-24 bg-white relative overflow-hidden">
      {/* Decorative background element */}
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:20px_20px] opacity-40"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          
          {/* Image/Visual Side */}
          <div className="w-full lg:w-1/2 relative">
            <div className="relative z-10 rounded-2xl overflow-hidden shadow-2xl border-4 border-white aspect-[4/3] group">
              <img 
                src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?q=80&w=2000&auto=format&fit=crop"
                alt="Sala Operatoria" 
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>
              
              <div className="absolute bottom-6 left-6 text-white">
                <p className="font-bold text-xl">Eccellenza Operativa</p>
                <p className="text-slate-300 text-sm">Standard elevati per ogni intervento</p>
              </div>
            </div>
            
            {/* Decorative offset border */}
            <div className="absolute top-6 -right-6 w-full h-full border-2 border-blue-600/30 rounded-2xl -z-0 hidden lg:block"></div>
            
            {/* Floating Badge */}
            <div className="absolute -top-6 -left-6 bg-blue-600 text-white p-6 rounded-2xl shadow-xl z-20 hidden md:block transform rotate-[-3deg] hover:rotate-0 transition-transform duration-300">
              <Award className="h-8 w-8 mb-2" />
              <p className="font-bold text-2xl">Leader</p>
              <p className="text-blue-100 text-sm">in Lombardia</p>
            </div>
          </div>

          {/* Content Side */}
          <div className="w-full lg:w-1/2">
            <h4 className="text-blue-600 font-bold uppercase tracking-widest text-sm mb-2">Chi Siamo</h4>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-8 leading-tight">
              Oltre la semplice <br/> fornitura medica.
            </h2>
            
            <p className="text-lg text-slate-600 mb-6 leading-relaxed">
              <span className="font-bold text-slate-900">Tagliani & Tedoldi</span> non è solo un fornitore, ma un partner tecnico integrato nel flusso di lavoro ospedaliero. Da Brescia operiamo in tutto il territorio, portando innovazione e sicurezza.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              {[
                { icon: Users, text: "Supporto tecnico in sala" },
                { icon: Clock, text: "Logistica rapida e precisa" },
                { icon: CheckCircle2, text: "Brand internazionali top-tier" },
                { icon: Award, text: "Consulenza certificata" }
              ].map((item, idx) => (
                <div key={idx} className="flex items-center p-3 bg-slate-50 rounded-lg border border-slate-100 hover:border-blue-200 hover:bg-blue-50 transition-colors">
                  <div className="bg-white p-2 rounded-md shadow-sm mr-3">
                    <item.icon className="h-5 w-5 text-blue-600" />
                  </div>
                  <span className="text-slate-700 font-medium text-sm">{item.text}</span>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-3 gap-0 border-t border-slate-200 pt-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center md:text-left pr-4">
                  <div className="text-3xl lg:text-4xl font-extrabold text-slate-900 mb-1">{stat.value}</div>
                  <div className="text-xs text-slate-500 font-bold uppercase tracking-wider">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
};

export default About;