import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, ArrowRight } from 'lucide-react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Grazie per averci contattato! Risponderemo al più presto.');
    setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  return (
    <section id="contatti" className="py-24 bg-slate-50 relative">
       {/* Background accent */}
       <div className="absolute bottom-0 right-0 w-1/3 h-1/2 bg-blue-100/50 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-8">
          
          {/* Info Side */}
          <div className="lg:col-span-2 space-y-10">
            <div>
              <h4 className="text-blue-600 font-bold uppercase tracking-widest text-sm mb-2">Contatti</h4>
              <h2 className="text-4xl font-bold text-slate-900 mb-6">Parliamo del tuo progetto</h2>
              <p className="text-slate-600 text-lg leading-relaxed">
                Siamo a vostra disposizione per consulenze tecniche, informazioni sui prodotti o richieste di collaborazione.
              </p>
            </div>

            <div className="space-y-8">
                <div className="flex items-start group">
                  <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 group-hover:border-blue-200 group-hover:shadow-md transition-all mr-5">
                    <MapPin className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-lg">Sede Operativa</h4>
                    <p className="text-slate-600">Via Creta 26<br />25124 Brescia (BS)</p>
                  </div>
                </div>

                <div className="flex items-start group">
                  <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 group-hover:border-blue-200 group-hover:shadow-md transition-all mr-5">
                    <Phone className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-lg">Telefono Diretto</h4>
                    <div className="flex flex-col gap-1 mt-1">
                      <a href="tel:+393482618794" className="text-slate-600 hover:text-blue-600 transition-colors flex items-center gap-2">
                        Nicola: <span className="font-medium">+39 348 2618794</span>
                      </a>
                      <a href="tel:+393456500219" className="text-slate-600 hover:text-blue-600 transition-colors flex items-center gap-2">
                        Alessandro: <span className="font-medium">+39 345 6500219</span>
                      </a>
                    </div>
                  </div>
                </div>

                <div className="flex items-start group">
                  <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 group-hover:border-blue-200 group-hover:shadow-md transition-all mr-5">
                    <Mail className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-lg">Email</h4>
                    <a href="mailto:tagliani.tedoldi@gmail.com" className="text-slate-600 hover:text-blue-600 transition-colors">tagliani.tedoldi@gmail.com</a>
                    <p className="text-slate-400 text-xs mt-1">PEC: taglianietedoldisrl@pec.it</p>
                  </div>
                </div>
            </div>
          </div>

          {/* Form Side */}
          <div className="lg:col-span-3">
            <div className="bg-white p-8 sm:p-10 rounded-3xl shadow-xl border border-slate-100">
              <h3 className="text-2xl font-bold text-slate-900 mb-8">Invia un messaggio</h3>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-semibold text-slate-700">Nome e Cognome</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white focus:border-transparent outline-none transition-all"
                      placeholder="Mario Rossi"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="phone" className="text-sm font-semibold text-slate-700">Telefono</label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white focus:border-transparent outline-none transition-all"
                      placeholder="+39 ..."
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-semibold text-slate-700">Email</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white focus:border-transparent outline-none transition-all"
                    placeholder="mario.rossi@email.com"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="subject" className="text-sm font-semibold text-slate-700">Oggetto</label>
                  <select
                    id="subject"
                    name="subject"
                    required
                    value={formData.subject}
                    onChange={handleChange}
                    className="w-full px-5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white focus:border-transparent outline-none transition-all appearance-none"
                  >
                    <option value="">Seleziona un argomento</option>
                    <option value="Informazioni Generali">Informazioni Generali</option>
                    <option value="Preventivo">Richiesta Preventivo</option>
                    <option value="Consulenza">Consulenza Tecnica</option>
                    <option value="Altro">Altro</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-semibold text-slate-700">Messaggio</label>
                  <textarea
                    id="message"
                    name="message"
                    rows={4}
                    required
                    value={formData.message}
                    onChange={handleChange}
                    className="w-full px-5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white focus:border-transparent outline-none transition-all resize-none"
                    placeholder="Come possiamo aiutarti?"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white font-bold py-4 px-6 rounded-xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-600/30 hover:shadow-blue-600/50 flex items-center justify-center gap-2 transform active:scale-95"
                >
                  Invia Messaggio
                  <Send size={18} />
                </button>
              </form>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Contact;