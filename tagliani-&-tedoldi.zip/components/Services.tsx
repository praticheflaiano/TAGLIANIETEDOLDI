import React from 'react';
import { Stethoscope, Archive, ShieldCheck, Truck, GraduationCap, Scissors, ArrowRight } from 'lucide-react';
import { ServiceItem } from '../types';

const services: ServiceItem[] = [
  {
    title: "Dispositivi Medici",
    description: "Fornitura di dispositivi medici certificati e all'avanguardia per il settore ortopedico e traumatologico.",
    icon: Stethoscope
  },
  {
    title: "Articoli Ortopedici",
    description: "Ampia selezione di articoli ortopedici per la riabilitazione e il recupero funzionale del paziente.",
    icon: Archive
  },
  {
    title: "Consulenza Tecnica",
    description: "Supporto specializzato e consulenza professionale per strutture ospedaliere e professionisti sanitari.",
    icon: ShieldCheck
  },
  {
    title: "Noleggio Attrezzature",
    description: "Servizio di noleggio attrezzature medicali con assistenza tecnica completa e manutenzione.",
    icon: Truck
  },
  {
    title: "Formazione",
    description: "Corsi di formazione e aggiornamento professionale sull'utilizzo di dispositivi e tecnologie medicali.",
    icon: GraduationCap
  },
  {
    title: "Strumentazione",
    description: "Fornitura di strumentazione chirurgica di alta precisione per interventi ortopedici e traumatologici.",
    icon: Scissors
  }
];

const Services: React.FC = () => {
  return (
    <section id="servizi" className="py-24 bg-slate-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="text-sm font-bold text-blue-600 tracking-[0.2em] uppercase mb-3">Le Nostre Competenze</h2>
          <h3 className="text-4xl font-bold text-slate-900 sm:text-5xl mb-6">Soluzioni Integrate a 360°</h3>
          <p className="text-lg text-slate-600 leading-relaxed">
            Un ecosistema completo di servizi pensati per l'eccellenza ospedaliera e la cura del paziente.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="group relative bg-white rounded-2xl p-8 shadow-sm hover:shadow-2xl transition-all duration-500 border border-slate-100 hover:border-blue-100 overflow-hidden"
            >
              {/* Hover Gradient Background */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              
              <div className="relative z-10">
                <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-blue-600 transition-colors duration-300 shadow-inner group-hover:shadow-lg group-hover:scale-110 transform">
                  <service.icon className="h-8 w-8 text-slate-700 group-hover:text-white transition-colors duration-300" />
                </div>
                
                <h4 className="text-xl font-bold text-slate-900 mb-4 group-hover:text-blue-700 transition-colors">{service.title}</h4>
                <p className="text-slate-600 leading-relaxed mb-6">
                  {service.description}
                </p>
                
                <div className="flex items-center text-blue-600 font-semibold text-sm opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                  Scopri di più <ArrowRight className="ml-2 h-4 w-4" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;